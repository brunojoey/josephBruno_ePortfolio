const db = require('../models');
const Trip = db.Trip;

// GET Route: /trips -- Lists all Trips
// Regardless of outcome, response must include HTML Status Code
// And JSON Message to the requesting client

const tripsList = async (req, res) => {
    const q = await Trip
        .findAll({})  // No filter, return all records

    // Results of Query if uncommented
    // console.log(q);

    if (!q) {
        return res
            .status(404)
            .json(err);
    } else {
        return res
            .status(200)
            .json(q);
    }
};

// GET Route: /trips/:tripCode -- Lists One Trip
// Regardless of outcome, response must include HTML Status Code
// And JSON Message to the requesting client

const tripsFindByCode = async (req, res) => {
    const q = await Trip
        .findOne({ where: { 'code': req.params.tripCode } });  // Return Single Record

    // Results of Query if uncommented
    // console.log("Trip Code", q);

    if (!q) {
        return res
            .status(404)
            .json(error);
    } else {
        return res
            .status(200)
            .json(q);
    }
};

// POST: /trips -- Add New Trip
// Regardless of outcome, response must include HTML Status Code
// and JSON message to the requesting client

const tripsAddTrip = async (req, res) => {
    const newTrip = await Trip
        .create({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

    if (!newTrip) {
        return res
            .status(400)
            .json(err);
    } else {
        return res
            .status(201)
            .json(newTrip);
    }

    // console log for results of operation
    // consolel.log(q);
}

// PUT: /trips/:tripCode -- Updates a trip
// Regardless of outcome, response must include HTML status code
// And JSON Message to the requesting client

const tripsUpdateTrip = async (req, res) => {
    // uncomment for debugging
    // console.log(req.params);
    // console.log(req.body);

    try {
        const [updatedCount] = await Trip
            .update(
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                { where: { code: req.params.tripCode } }
            );

        if (updatedCount === 0) {
            return res
                .status(404)
                .json("Trip Not Found, Or Changes Not Made");
        };

        const updatedTrip = await Trip.findOne({
            where: { code: req.params.tripCode }
        });
        // console.log(updatedTrip)

        // database returned no data
        return res
            .status(200)
            .json(updatedTrip);

    } catch (error) {
        // console.log("error updating the trip: ", error);
        return res
            .status(500)
            .json({ error: "Internal Server Error" });
    }
}

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};