const { DataTypes, Model } = require("sequelize");

module.exports = (sequelize, Sequelize) => {
    if (!sequelize || typeof sequelize.define !== 'function') {
        throw new Error("Trip Model Requires Valid Sequelize Instance");
    }

    class Trip extends Model { }

    Trip.init({
        code: { type: DataTypes.STRING, allowNull: false, primaryKey: true },
        name: { type: DataTypes.STRING, allowNull: false },
        length: { type: DataTypes.STRING, allowNull: false },
        start: { type: DataTypes.DATE, allowNull: false },
        resort: { type: DataTypes.STRING, allowNull: false },
        perPerson: { type: DataTypes.STRING, allowNull: false },
        image: { type: DataTypes.STRING, allowNull: false },
        description: { type: DataTypes.STRING, allowNull: false }
    }, {
        sequelize,
        modelName: "Trip"
    });

    return Trip;
}