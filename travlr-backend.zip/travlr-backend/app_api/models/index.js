const dbConfig = require("../config/db");
const Sequelize = require("sequelize");

const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    port: dbConfig.PORT,
    dialect: dbConfig.dialect,
    dialectOptions: dbConfig.dialectOptions,

    pool: {
        max: dbConfig.pool.max,
        min: dbConfig.pool.min,
        acquire: dbConfig.pool.acquire,
        idle: dbConfig.pool.idle
    }
});

// initialize DB
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.Trip = require("./travlr")(sequelize, Sequelize);
db.User = require("./user")(sequelize, Sequelize);

module.exports = db;