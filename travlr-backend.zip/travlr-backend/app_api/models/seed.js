// Bring in the DB connection and the Trip Schema
const db = require('./index');
const Trip = db.Trip;


// Read Seed Data from JSON File
var fs = require('fs');
var trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf-8'));

// drop any existing records, then create new seed data
const seedDB = async () => {
    try {
        await db.sequelize.authenticate();
        // console.log("MySQL Connected Successfully");

        // remove trip records
        await Trip.destroy({
            where: {},
            truncate: false
        });

        // insert trip records
        await Trip.bulkCreate(trips);
    } catch (error) {
        console.error("Seeding Failed: ", error);
    } finally {
        // close connection and exit
        await db.sequelize.close();
        process.exit(0);
    }
    
};

seedDB();