const { Sequelize, DataTypes, Model } = require('sequelize');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

module.exports = (sequelize, Sequelize) => {
    // Create User Sequelize Model
    class User extends Model {
        // Method to set the password on this record
        setPassword = function (password) {
            this.salt = crypto.randomBytes(16).toString('hex');
            this.hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64, 'sha512').toString('hex');
        }

        // Method to compare entered password against stored hash
        validPassword = function (password) {
            var hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64, 'sha512').toString('hex');
            return this.hash === hash;
        };

        generateJWT = function () {
            return jwt.sign({
                // Payload for JSON Web Token
                _id: this._id,
                email: this.email,
                name: this.name
            },
                process.env.JWT_SECRET, // Secret stored in .env file
                { expiresIn: '1h' }); // Token expires an hour from creation
        };
    }

    User.init({
        // email: required, unique
        email: {
            type: DataTypes.STRING, allowNull: false, unique: true, validate: {
                isEmail: true
            }
        },
        // name: required
        name: { type: DataTypes.STRING, allowNull: false },
        hash: { type: DataTypes.STRING },
        salt: { type: DataTypes.STRING },
    }, {
        sequelize,
        modelName: "User"
    });

    return User;
};