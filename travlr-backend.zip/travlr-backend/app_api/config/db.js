require('dotenv').config();

const isProduction = process.env.NODE_ENV === 'production';

if (isProduction && !process.env.JAWSDB_URL) {
    throw new Error('JAWSDB_URL is missing from Heroku');
}

const config = {
    HOST: process.env.DB_HOST || '127.0.0.1',
    PORT: process.env.DB_PORT || 3306,
    USER: process.env.DB_USER,
    PASSWORD: process.env.DB_PASSWORD,
    DB: process.env.DB_NAME,
    dialect: 'mysql',
    dialectOptions: {},
    pool: {
        max: process.env.DB_POOL_MAX || 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
};

if (isProduction) {
    const url = new URL(process.env.JAWSDB_URL);

    config.HOST = url.hostname;
    config.PORT = url.port || 3306;
    config.USER = decodeURIComponent(url.username);
    config.PASSWORD = decodeURIComponent(url.password);
    config.DB = decodeURIComponent(url.pathname.slice(1));
}

module.exports = config;
