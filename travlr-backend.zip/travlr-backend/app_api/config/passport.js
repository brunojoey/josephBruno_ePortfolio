const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const db = require('../models');
const User = db.User;

passport.use(
    new LocalStrategy(
        {
            usernameField: "email",
        },
        async (username, password, done) => {
            const q = await User.findOne({ where: { email: username } });
            // console.log("Email: ", q);
            if (!q) {
                return done(null, false, {
                    message: "Incorrect Username",
                });
            } 
            
            if (!q.validPassword(password)) {
                return done(null, false, {
                    message: "Incorrect Password",
                });
            }
            return done(null, q);
        }
    )
);

module.exports = passport;