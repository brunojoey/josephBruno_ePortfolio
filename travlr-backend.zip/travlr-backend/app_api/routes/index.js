const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Authentication Routes
router.route('/register').post(authController.register);
router.route('/login').post(authController.login);

// Route for All Trips Endpoint
router
    .route('/trips')
    .get(tripsController.tripsList) // GET Method to get all trips
    .post(authenticateJWT, tripsController.tripsAddTrip); // POST Method to Add a Trip

// GET Method routes tripsFindByCode = requires parameter
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip);

// Method to authenticate the JWT
function authenticateJWT(req, res, next) {
    // console.log('In Middleware');

    const authHeader = req.headers['authorization'];
    // console.log('Auth Header: ' + authHeader);

    if (authHeader == null) {
        // console.log('Auth Header Required but Not Present!');
        return res.sendStatus(401);
    }

    const [scheme, token] = authHeader.split(' ');

    if (scheme !== 'Bearer' || !token) {
        console.log("A Valid Bearer Token is Required");
        return res.status(401);
    };
    

    // console.log(process.env.JWT_SECRET);
    // console.log(jwt.decode(token));
    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            return res.sendStatus(401).json('Token Validation Error!');
        }

        req.auth = verified; // Set Auth Parameter to the decoded object
        return next();
    });
}

module.exports = router;