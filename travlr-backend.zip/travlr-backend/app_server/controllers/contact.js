/* GET Contact Page Request */
const contact = (req, res) => {
    res.render('contact', {title: 'Travlr Getaways'});
}

module.exports = {
    contact
}