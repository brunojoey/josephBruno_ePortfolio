var fs = require('fs');
var meals = JSON.parse(fs.readFileSync('./data/meals.json', 'utf-8'));

/* GET Room Page Request */
const meal = (req, res) => {
    res.render('meals', {title: 'Travlr Getaways', meals});
}

module.exports = {
    meal
}