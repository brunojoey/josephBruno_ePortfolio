/* GET Travlr Page Request */
const travel = async (req, res, next) => {
    try {
        // Build the API URL inside the request handler.
        const tripsEndpoint = `${req.protocol}://${req.get('host')}/api/trips`;

        const response = await fetch(tripsEndpoint, {
            method: 'GET',
            headers: {
                Accept: 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Trips API returned status ${response.status}`);
        }

        const trips = await response.json();

        if (!Array.isArray(trips)) {
            return res.status(502).render('travel', {
                title: 'Travlr Getaways',
                trips: [],
                message: 'API Lookup Error'
            });
        }

        const message = trips.length === 0
            ? 'No trips exist in the database'
            : null;

        return res.render('travel', {
            title: 'Travlr Getaways',
            trips,
            message
        });
    } catch (err) {
        console.error('Trips Controller Error:', err.message);
        return next(err);
    }
};

module.exports = { travel };