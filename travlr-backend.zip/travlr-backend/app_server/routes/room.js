var express = require('express');
var router = express.Router();
const controller = require('../controllers/room');

/* GET Room Page */
router.get('/', controller.room);

module.exports = router;