var express = require('express');
var router = express.Router();
const controller = require('../controllers/meal');

/* GET Room Page */
router.get('/', controller.meal);

module.exports = router;