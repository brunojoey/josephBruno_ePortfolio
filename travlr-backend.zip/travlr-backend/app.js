// User Database Authentication
require('dotenv').config();

const createError = require('http-errors');
const http = require('http');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const handlebars = require('hbs');

// initialize Express App
const app = express();

// Wire in authentication module
const passport = require('passport');
require('./app_api/config/passport');

// Port ENV
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';

// Bring in Database
const db = require('./app_api/models/index');

// create server on the express App
const server = http.createServer(app);

// start the server with Sequelize authenticating and synchronizing the database
const startServer = async () => {
  try {
    await db.sequelize.authenticate();

    if (NODE_ENV !== 'production') {
      await db.sequelize.sync();
    };

    server.listen(PORT, '0.0.0.0', () => {
      console.log(`Server running in ${NODE_ENV} Mode on Port: ${PORT}`);
    });
  } catch (err) {
    console.log("Application startup failed: ", err.message);
    process.exit(1);
  }
};

startServer();

// Trust Reverse Proxy When Deployed
if (process.env.TRUST_PROXY === 'true') {
  app.set('trust proxy', 1);
}

// Router Requirements
var indexRouter = require('./app_server/routes/index');
var usersRouter = require('./app_server/routes/users');
var travelRouter = require('./app_server/routes/travel');
var roomRouter = require('./app_server/routes/room');
var mealRouter = require('./app_server/routes/meal');
var contactRouter = require('./app_server/routes/contact');
var aboutRouter = require('./app_server/routes/about');
var newsRouter = require('./app_server/routes/news');
var apiRouter = require('./app_api/routes/index');

// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));

// register handlebars partials
handlebars.registerPartials(
  path.join(__dirname, 'app_server', 'views', 'partials')
);app.set('view engine', 'hbs');

app.use(logger(NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

// CORS Configuration
const allowedOrigins = (process.env.CORS_ORIGIN || (NODE_ENV === 'development' ? 'http://localhost:4200' : ''))
  .split(',')
  .map(origin => origin.trim().replace(/\/$/, ''))
  .filter(Boolean);

app.use('/api', (req, res, next) => {
  const origin = req.headers.origin;

  if (origin && allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Vary', 'Origin');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  }

  // Handle browser CORS preflight requests
  if (req.method === 'OPTIONS') {
    if (origin && !allowedOrigins.includes(origin)) {
      return res.sendStatus(403);
    }

    return res.sendStatus(204);
  }

  next();
});

// Router Links
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/rooms', roomRouter);
app.use('/meals', mealRouter);
app.use('/contact', contactRouter);
app.use('/about', aboutRouter);
app.use('/news', newsRouter);
app.use('/api', apiRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  if (res.headersSent) {
    return next(err);
  };

  const statusCode = err.status || err.statusCode || 500;

  // render the error page
  res.status(statusCode);

  // Return JSON for API errors
  if (req.originalUrl.startsWith('/api')) {
    return res.json({
      message:
        NODE_ENV === 'production' && windows.status >= 500 ? 'Internal Server Error' : err.message
    });
  };

  res.locals.message = NODE_ENV === 'production' && status >= 500 ? 'Internal Server Error' : err.message
  res.locals.error = NODE_ENV === 'development';
  
  return res.render('error');

});

// Catch unauthorized error and create 401
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    res
      .status(401)
      .json({ "message": err.name + ": " + err.message });
  }
});

module.exports = app;
